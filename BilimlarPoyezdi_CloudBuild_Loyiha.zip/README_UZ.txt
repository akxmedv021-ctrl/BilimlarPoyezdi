BILIMLAR POYEZDI — ANDROID LOYIHASI (CLOUD BUILD)

Bu loyiha tayyor APK emas. GitHub Actions orqali bulutda APK yig'ish uchun
workflow qo'shilgan.

TELEFONDAN APK YIG'ISH:
1. GitHub.com saytida hisob yarating yoki hisobingizga kiring.
2. New repository yarating. Nomi: BilimlarPoyezdi. Public yoki Private bo'lishi mumkin.
3. Ushbu ZIP faylni oching. Ichidagi barcha fayl va papkalarni repository'ga yuklang.
   Muhim: .github papkasi ham yuklanishi shart.
4. GitHub repository ichida Actions bo'limini oching.
5. "Build Android APK" workflow'ini tanlang va "Run workflow" ni bosing.
6. Jarayon tugagach, muvaffaqiyatli run ichidan Artifacts bo'limidagi
   BilimlarPoyezdi-debug-apk faylini yuklab oling.
7. Yuklangan ZIP ichidan app-debug.apk faylini chiqarib, Android telefoningizga
   o'rnating.

Loyiha talablari: Android SDK 35, JDK 17, Gradle 8.7.
Hozirgi ilova — WebView ichidagi dastlabki HTML prototip. Haqiqiy 3D o'yin emas.
